import { Component, ViewChild } from '@angular/core';
import { IonTabs } from '@ionic/angular';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false,
})
export class AppComponent {
  @ViewChild('myTabs', { static: false }) tabs!: IonTabs;

  selectedIndex = 0;
  selected = false;
  activeTabName: string | undefined = '';
  tab_name: any;

  appPages = [
    { title: 'Inbox', url: '/folder/inbox', icon: 'mail' },
    { title: 'Outbox', url: '/folder/outbox', icon: 'paper-plane' },
    { title: 'Favorites', url: '/folder/favorites', icon: 'heart' },
    { title: 'Archived', url: '/folder/archived', icon: 'archive' },
    { title: 'Trash', url: '/folder/trash', icon: 'trash' },
    { title: 'Spam', url: '/folder/spam', icon: 'warning' },
  ];

  labels = ['Family', 'Friends', 'Notes', 'Work', 'Travel', 'Reminders'];

  getSelectedTab(): void {
    if (this.tabs) {
      this.selected = true;
      this.activeTabName = this.tabs.getSelected() || '';
      this.tab_name = this.activeTabName;
    }
  }
}